//: [Previous](@previous)

/*:
 ---
 
 ## Properties
 ---
 */

struct Wizard {
    var firstName: String {
        willSet {
            print("\(firstName) will be set to \(newValue)")
        }
        didSet { // WIth didSet you can make changes to the value
            if firstName.contains(" ") {
                print("No spaces allowed! \(firstName) is not a first name. Reverting to \(oldValue)")
                firstName = oldValue
            }
            
        }
    }
    var lastName: String
    
    //: Create a computed property - Remember they always start with var. Because you are always going to return a value.
    
    var fullName: String {
        get {return "\(firstName) \(lastName)"}
        set(newValue) {
            let nameSubstrings = newValue.split(separator: " ")
            
            guard nameSubstrings.count >= 2 else {
                print("\(newValue) is not a full name")
                return
            }
            let nameStrings = nameSubstrings.map(String.init)
            firstName = nameStrings.first!
            lastName = nameStrings.last!
        }
    }
    
}

var wizard = Wizard(firstName: "Harry", lastName: "Potter") // The first and last name are stored properties.
wizard.fullName
wizard.firstName = "Isaac Harry"

/*:
 ---
 ### LAZY VARIABLES:

 You declare a lazy var when the variable will take up alot of memory or is complicated, You do this so the variable will only execute when it is needed.
 
 - Could be constant
 - Expensive to calculate
 - Might not be used by every instance

 **Exercise**
 
 Create a struct named Temperature with properties for degrees in both Celcius and fahrenheit, as Doubles.
 
 - One property must be stores, but the other can be computed.
 - To convert F to C substact 32 then divide by 1.8
 
 ---
 **COMPUTED PROPERTIES VS METHODS**
 - Properites hold values
 - Methods perform work
 */

struct Temperature {
    var degreesF: Double
    var degreesC: Double {
        get {return (degreesF - 32) / 1.8 }
        set { degreesF = newValue * 1.8 + 32 }
    }
}
var temp = Temperature(degreesF: 32)
temp.degreesC

//: A value can be computed rather than stored
//: A typical stored property: var foo: Double
//: Computed Properties calculate a value instead of storing them.
//: A computed property:
var foo: Double {
    get {
        // return calculated value of foo
    } 
    set(newValue) {
        // Do something based on the fact that foo has changed to newValue
    }
}

//: [Next](@next)
