//: [Previous](@previous)
/*:
 ---
 ## Closures + Networking
 ---
 
 - A closure is like an unnamed (anonymous) function that can be stored in a variable/constant or passed around.
 - Functions and closures have their own types, the same way other objects have types (e.g. Bool, Int, String, etc.)
 - The type of a closure or function is '(paramTypes) -> returnType'
 - The value of closures is that they can be stored in variables/constants and/or passed as parameters to functions.
 
  **Closure syntax:**
 
    { (parameter1Name: parameter1Type, ...) -> returnType in
        code to execute
      }
 */
//: **Different types of Functions**
//: Type: ( ) -> ( )
func simpleFunction() {
    print("executing function")
}
simpleFunction()
//: Type: (String, Bool) -> ( )
func anotherSimpleFunction(input: String, input2: Bool) {
}
//: Type: ( ) -> Bool
func anotherSimpleFunction2() -> Bool {
    return true
}
// Type: (String) -> Bool
func complexFunction2(input: String) -> Bool {
    return true
}
complexFunction2(input: "hello")

//: **Corresponding types of Closures**
//: Type: ( ) -> ( )
var simpleClosure = {
    print("executing closure")
}
simpleClosure()
//: Type: (String, Bool) -> ( )
var anotherSimpleClosure = { (input: String, input2: Bool) in
}
//: Type: ( ) -> Bool
var anotherSimpleClosure2 = { () -> Bool in
    return true
}
//: Type: (String) -> Bool
var complexClosure = { (input: String) -> Bool in
    print("\(input)")
    return true
}
complexClosure("hello")
//: ---
//: Mock Network Request Using Closures
func makeNetworkRequest(searchQuery: String, completion: ([String]) -> ()) {
    /*
     make network request on a different thread
     .
     .
     .
     */
    // call completion handler once that work is done
    let dataArray = [ "data1", "data2" ]
    completion(dataArray)
}
// long form
makeNetworkRequest(searchQuery: "data", completion: { (dataArray: [String]) in
    for item in dataArray {
        print("\(item)")
    }
    print("executing closure")
})
// short form, when a closure is the last argument to a function - 'trailing closure syntax'
makeNetworkRequest(searchQuery: "data") { (dataArray: [String]) in
    for item in dataArray {
        print("\(item)")
    }
    print("executing closure")
}

/*: **Networking**
What happens when you do a Google search?
Making a request and getting back a response
For a website, we get back html, javascript, css
For an API (Application Programming Interface) -> JSON, XML */
/*
 Keys: String - this can be represented as String in Swift
 Values: Bool, String, Int, Double, Arrays, Dictionaries, null - these can be represented as Any? in Swift
 Example JSON:
     {
        "albumId": [1, 2, 3, 4],
        "id": null,
        "title": "accusamus beatae ad facilis cum similique qui sunt",
        "url": "http://placehold.it/600/92c952",
        "thumbnailUrl": "http://placehold.it/150/92c952"
        }
 This can be represented in Swift as a [String: Any?]
 */

/*: HTTP: TyperText Transfer Protocol
- Different Types: CRUD: Create, Read, Update, Delete
- Create: POST
- Read: GET
- Update: PUT/PATCH
- Delete: DELETE
 */
/*:
 **Async Programming**
 - UI interaction is handled on the main thread
 - Any work scheduled on the main thread will block user interactions until it is finished
 - Asynchronous code allows non-UI code blocks to execute on a different thread, freeing up the main thread for smooth UI/UX
 - If we do our network call on the main thread, it will block all UI interaction until the network call is finished (BAD)
 - Async programming lets us dispatch a network request on a different thread, and then handle it once the response has been received
 - Closures are a handy way to provide a block of code to execute once an asynchronous task has completed
 */

//: [Next](@next)
