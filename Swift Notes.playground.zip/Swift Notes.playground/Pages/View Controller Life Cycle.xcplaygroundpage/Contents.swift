//: [Previous](@previous)
/*:
 ---
 ## View Controller Life Cycle
 ---
 **View Did Load:**
 
 After you have instantiated a view controller, the view controller will load the view into memory. After the view controller has finished loading its particular views, the viewDidLoad() function is called, giving the controller a chance to perfrom work that depends on the view being loaded and ready. For example, setup tasks, network requests, database access and more.
 
 You must always use the override keyword to override the superclass method, and must always call super.
 
 ---
 **View Will Appear:**
 
 This is called right before the view appears on the screen. This is a good place to add work that needs to be performed before the view is displayed to the user.
 
 For example, if your view displays information relative to the users location, you may want to request the location in viewWillAppear. That way, the view can be updated to take advantage of the new location. Other tasks include: Starting network requests, refreshing or updating views, or adjusting to screen orientation.
 
 ---
 **View Did Appear:**
 
 This is called after the view appears on the screen. If your work needs tobe performed each time the view appears but may require more than a few seconds, place it here.
 
 Good for animations, or getching data.
 
 ---
 **View Will Disappear:**
 
 This is called before the view disappear from the screen. It executes when the user navigates away from the screen by taping the back button or switching tabs, or presenting / dismissing a modal screen.
 Use this method for saving edits, hiding the keyboard, or cancelling network requests.
 
 ---
 **View Did Disappear:**
 
 This is called after the view disappears from the screen. Typically after the user has navigated to a new view.
 */


//: [Next](@next)
