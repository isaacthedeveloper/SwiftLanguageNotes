//: [Previous](@previous)

//: ---
//: # Control Flow & Functions
//: ---
//: ## If Statement
if true {
    print("This is printing because the condition is true")
}
if false {
    print("This will never print because the if condition is false")
}
//: Exercise: Write an if statement that will print "Logged in successfully" when the user's credentials match stored credentials
var enteredUsername = "myUsername123"
var enteredPassword = "myPassword"
var correctUserName = "myUsername"
var correctPassword = "myPassword"
if (enteredUsername == correctUserName) && (enteredPassword == correctPassword) {
    print("Logged in successfully")
}
//: - - -
//: ## If-Else If-Else
//:
//: Exercise 2: Print "Logged in successfully" if correct, and “Incorrect credentials” if incorrect
if (enteredUsername == correctUserName) && (enteredPassword == correctPassword) {
    print("Logged in successfully")
}
else {
    print("Incorrect credentials")
}
//: Comparison and logical operators can be used to create complex logic
var a = 0
if a > 2 && a != 1 {
    print("a > 2 && a != 1")
}
else if a == 3 {
    print("a equals 3")
}
else if a == 6 {
    print("a equals 6")
}
else {
    print("no condition was satisfied")
}
//:
//:Exercise 3: Print a response depending on input (“Logged in successfully”, “Username is incorrect”, “Password is incorrect”, “Incorrect credentials” (when both are wrong) )
if enteredUsername == correctUserName && enteredPassword == correctPassword {
    print("Logged in successfully")
}
else if enteredUsername != correctUserName {
    print("Username is incorrect")
}
else if enteredPassword != correctPassword {
    print("Password is incorrect")
}
else {
    print("Incorrect credentials")
}
//:
/*:
 ---
 ### **Scope**
 
 Scope defines where a variable/constant is valid/accessible using its name
 - For example, you cannot access a variable before it is declared
 
 - When a variable is defined, it is accessible in the current scope and all child scopes of the current scope
 - New scopes are created between a set of curly braces ( { } )
 - Every new scope should shift the indentation of your code right by one tab -> this makes
 it easy to determine what scope you are in at a glance
 
**Rules**:
 - Variables/constants declared inside a given scope are accessible inside child scopes
 - Variables/constants declared inside a child scope are not accessible in the parent scopes
 
 **Naming**:
 - Variables/constants with reused names can be declared as long as the declaration happens in a new scope - you can never redeclare a variable/constant in the same scope
 
 - When you have variables declared with the same name across different scopes, the one in
 the nearest scope will be used, with the search starting with the current scope, and working outward to
 parent scopes
 */
//: Scope example:
let value = true
if value { // <- `{` creates a new, child scope, and the indent shifts one tab to the right
    print("this will run")
    // you will not get a redeclaration error here since this is in a different scope from the original
    let value = false
    // the nearest `value` is the one in the current scope (declared in the line above), which is false
    if value {
        print("this will not run")
    }
    else {
        print("this will run")
    }
}
else {
    print("this will not run")
}

print(value) // <- prints 'true', since the `value` in the nearest scope is the one declared at the beginning of this example. Note: 'Nearest scope' does not mean 'closeness in number of lines of code'


/*:
 ---
 ### **Switch Statements**

 - Switches are like if statements, but are required to be exhaustive.
 - This is almost like having a mandatory `else` on an `if..else if` chain if not all cases have been covered
*/
var b = 0
switch b {
case -1...1:
    print("b is between -1 and 1")
case 2:
    print("b is 2")
case 3:
    print("b is 3")
default:
    print("b did not match any of the cases")
}

/*:
 - - -
 ## **Loops**
 
     for `element` in `sequence` {
          execute some code using the current `element` in `sequence`
          }
 

 A `for` loop iterates over a sequence of elements, one at a time, assigning each element to a temporary constant and then executing the loop body.
 
 Examples of sequences that can be used in a for loop are  Arrays, Ranges, and Dictionaries

 ### **For Loop using an Array**
Exercise: Print a greeting for each name in an array
 */
let greeting = "Hello"
var names = [ "Sarah", "Gary", "Noel" ]
for name in names {
    print("\(greeting), \(name)")
}
//: Exercise: Print names in an array next to their index
var counter = 0
for name in names {
    print("\(counter): \(name)")
    counter = counter + 1
}
//: Another solution
for x in 0...names.count - 1 {
    let name = names[x]
    print("\(x): \(name)")
}
/*:
  ### **For Loop using a Range**
 Exercise: Print numbers from 1 to 5 (using a Range)
*/
for number in 1...5 {
    print("\(number)")
}
//: Another solution
for number in 1..<6 {
    print("\(number)")
}
//: ### **For Loop using a Dictionary**
var contactInfoDictionary: [String: String] = [ "name": "Sarah",
                                                "address": "123 Fake St",
                                                "phoneNumber": "1234567890" ]
for (key, value) in contactInfoDictionary {
    print("The key \(key) has a value of \(value)")
}
//: Exercise: Given a dictionary where the keys are names and the values are phone numbers, use a loop to print a list of people's names with their corresponding phone number e.g. "[key]'s phone number is [value]"
var phoneBook: [String: String] = [ "Eric": "1234567890",
                                    "Mike": "01284841724",
                                    "Britney": "1234567890" ]
for (name, phoneNumber) in phoneBook {
    print("\(name)'s phone number is \(phoneNumber)")
}
/*:
 ### **While Loop**
     while `condition` {
         execute this code if `condition` is true
        }
 
  - While loops execute a block of code repeatedly, as long as a given condition is satisfied.
  - While loops are more dangerous than `for in` loops, because if you are not careful about ensuring `condition` is false at some point, you can end up with an infinite loop, and your app will potentially hang if this is not intended.
*/
var index = 0
while index < names.count {
    let name = names[index]
    print("\(greeting), \(name)")
    // increment the counter to ensure the while `condition` becomes false
    // when we run out of elements in the `names` array
    index = index + 1
}
//: Same loop using a `for in` loop
//: Safer and more concise for iterating over sequences of elements
for name in names {
    print("\(greeting), \(name)")
}
/*:
 ### **Repeat-While Loop**
Similar to a `while` loop, except the `condition` is evaluated after at least one execution of the loop body. */
var repeatWhileCounter = 0
repeat {
    print("this gets executed because the condition isn't evaluated until after one repition")
    repeatWhileCounter = repeatWhileCounter + 1
} while repeatWhileCounter < 0

/*:
 ### **Functions**
 - Named, reusable blocks of code which encapsulates logic that performs a given function.
 - Functions are defined once, but can be called upon many times.
 - Useful because it minimizes code repetition and increases code readability.
- Functions can take in 0 or more inputs (called parameters) and output a value (called a return value).
- You need to "call" a function in order to have its logic execute.
- You use a function to define a task, which you can execute as many times as you like.
- Functions can take zero or more parameters
- You can add an external name to a function parameter to change the label you use in a function call or you can use an underscore to denote no label.
- Parameters are passed as constants, unless you mark them as inout, in which case they are copied-in copied-out.
- Functions can have the same name with different parameters (overloading).
- Functions can have a special Never return type to inform swift that the function will never exit. (Use if there is corrupt data)/
- You can assign functions to variable and pass them to other functions.
- Functions should only have one job.
 
      func functionName(paramName1: paramType1) -> return {
           add function logic
        }
 */
//: Function with no parameters and no return type (simplest)
func sayHello() {
    print("Hello")
}
sayHello()

//: Function with parameters an no return type
func sayHello(name: String) {
    print("Hello, \(name)")
}
sayHello(name: "Stephanie")
//: If a function has a return type, it will need to `return` a value for all execution paths in the function
func areaOfRectangle(length: Double, width: Double) -> Double {
    let area = length * width
    return area // Returns area of type double.
}
let length: Double = 3.0
let width: Double = 5.0
let area = areaOfRectangle(length: length, width: width) // assign the return value of the function to a constant
areaOfRectangle(length: 5.0, width: 10.0) // you can call the same function as many times as you want
areaOfRectangle(length: 15.0, width: 100.0)
areaOfRectangle(length: 2.3, width: 3.4)

func volumeOfRectangularPrism(length: Double, width: Double, height: Double) -> Double {
    let volume = width * length * height
    return volume
}
let sideLength: Double = 10
let volumeOfCube = volumeOfRectangularPrism(length: sideLength, width: sideLength, height: sideLength)

/*: External vs Internal parameter names

        func (parameter1ExternalName parameter1InternalName: parameter1Type, ...) -> returnType { }
Choosing a different external name can make calling a function read more like a sentence
 */
func printGreeting(for name: String) {
    print("Hello, \(name)")
}
printGreeting(for: "Gary")

/*:
 ---
 ### **Enumerations**
 - Creates a new Type, used to specify a finite number of cases
 - Always name enumerations starting with a capital letter, since they are a Type */
enum Direction {
    case north, east, west, south // short form
    // long form
    //    case north
    //    case east
    //    case west
    //    case south
}
//: You can back an enumeration with a raw value by using type annotation syntax (in this case, using String)
enum DirectionWithRawValue: String {
    case north, east, west, south
}
//: A case's raw value can be accessed by appending `.rawValue` to a case
DirectionWithRawValue.north.rawValue // <- this is the String "north"


let direction: Direction = Direction.west
//let direction: Direction = .west // < if you type annotate, you can drop the enumeration name
//let direction = Direction.west // <- if you don't type annotate, you have to use the full form
switch direction {
case Direction.north:
    print("The direction is north")
case Direction.east:
    print("The direction is east")
case Direction.west:
    print("The direction is west")
case Direction.south:
    print("The direction is south")
}
let directionUsingString: String = "west"
switch directionUsingString {
case "North":
    print("North")
case "East":
    print("East")
case "South":
    print("South")
case "West":
    print("West")
default:
    print("Didn't match any direction") // < this will print because we misspelt 'West'
}

/*:
 ### **Tuples**
 - All it is, is grouping values together.
 - Tuples are good for when you need to return multiple values from a function. */
let x: (String, Int, Double) = ("hello", 5, 0.95)
let (word, number, value1) = x
print(word)
print(number)
print(value1)


//: [Next](@next)
