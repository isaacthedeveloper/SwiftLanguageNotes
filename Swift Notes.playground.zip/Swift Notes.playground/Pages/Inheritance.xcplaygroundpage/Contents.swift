//: [Previous](@previous)

/*:
 ---
 
 ## Inheritance
 ---
 */

struct Grade {
    var letter: Character
    var points: Double
    var credits: Double
}

class Person {
    var firstName: String
    var lastName: String
    
    init(firstName: String, lastName:String) {
        self.firstName = firstName
        self.lastName = lastName
    }
}

//: Make Student inherit the properties from the Person class by type anotating it so we do not have duplicate code

class Student: Person {
    var grades: [Grade] = []
    
    /*var firstName: String
     var lastName: String
     
     init(firstName: String, lastName: String) {
     self.firstName = firstName
     self.lastName = lastName
     }*/
}

let isaac = Person(firstName: "Isaac", lastName: "Ballas")
let john = Student(firstName: "John", lastName: "Doe")

isaac.firstName
isaac.lastName

let historyGrade = Grade(letter: "A", points: 10, credits: 3)

//: ONLY STUDENTS HAVE ACCESS TO A GRADE - a Person cannot have a grade.

//:   Isaac is a Person so he cannot access the grades.

//isaac.grades.append(historyGrade)
john.grades.append(historyGrade) // John is a student so he can access grades.

//: Define a new class called SchoolBandMember that inherits from Student.
class SchoolBandMember: Student { // Sublass here is Student.
    // Already Inherits name and grade properties.
    var minimumPracticeTime = 2
}

//: Define another class that inherits from Student
class StudentAthelete: Student {
    // Already inherits name and grade properties.
    // Student athlete will not be eligible if the have 3 F grades. Make a computed property to solve this.
    var isEligible: Bool {
        return grades.filter {$0.letter == "F" } .count < 3
    }
    override var grades: [Grade] {
        // Turn this into a computed property.
        get{
            return super.grades
        }
        set {
            super.grades = newValue
            if !isEligible {
                print("Time to study")
            }
        }
    }
    
}

/*:
 ---
 ### POLYMORPHISM -> A subclass can be treated as its own type, or as any of its superclasses.
 Define a band member and a student athelete.
 */
let revital = SchoolBandMember(firstName: "Revital", lastName: "Titane")
let brian = StudentAthelete(firstName: "Brian", lastName: "Slabotsky")
//: Put everyone defined so far into an array.
let array = [isaac, john, revital, brian] // This is an array of type Person.
//: Create the same array, but only allow it to hold Students
let studentArray: [Student] = [john, revital, brian]

//: You can cast from a subclass to a superclass by using the as! keyword followed by a type to cast to.
let athelete = student as! StudentAthelete

func getEveningActivity(student: Student) -> String {
    if let bandMember = student as? SchoolBandMember {
        return "Practicing for at least \(bandMember.minimumPracticeTime) hours"
    } else {
        return "Hitting the books"
    }
}

getEveningActivity(student: brian)
getEveningActivity(student: john)
getEveningActivity(student: revital)


//: [Next](@next)
