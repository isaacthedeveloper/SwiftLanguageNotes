//: [Previous](@previous)
/*:
 ---
 
 ## Methods
 ---
 */

enum Weekday: CaseIterable {
    case monday, tuesday, wednesday, thursday, friday, saturday, sunday
    
    mutating func advance(by dayCount: UInt) { // Use mutating so the day changes.
        // Use UInt since we are dealing with negative numbers.
        // Get the index of the day we are working with.
        let indexOfToday = Weekday.allCases.firstIndex(of: self)!
        let indexOfAdvancedDay = indexOfToday + Int(dayCount) // Convert dayCount to INT or else it will produce an error.
        
        self = Weekday.allCases[indexOfAdvancedDay % Weekday.allCases.count]
    }
}

Weekday.allCases
var weekday: Weekday = .tuesday
weekday.advance(by: 6)

//: Define a struct taht uses your weekday type.
struct Time {
    var day: Weekday
    var hour: UInt
    
    init(day: Weekday, hour: UInt = 0) {
        self.day = day
        self.hour = hour
    }
    mutating func advance(byHours hourCount: UInt) {
        // Get sum of time hour and hour count parameter.
        let (dayCount, hour) = (self.hour + hourCount).quotientAndRemainder(dividingBy: 24)
        day.advance(by: dayCount)
        self.hour = hour
    }
    func advanced(byHours hourCount: UInt) -> Time {
        var time = self
        time.advance(byHours: hourCount)
        return time
        
    }
}

var time = Time(day: .monday)
time.advance(byHours: 24 * 3 + 5)
time

/*:
 - Create a structure named Student with three properties: first name, last name and grade.
 - Create a structurew named Classroom with two properties: The class name, and an array of students
 - Create a method that returns the highest grade in the classroom.
 */

struct Student {
    let firstName: String
    let lastName: String
    var grade: Int
}

struct Classroom {
    let className: String
    var students: [Student]
    
    func getHighestGrade() -> Int? {
        // Get students grade using map
        return students.map { $0.grade } .max() // max() picks the highest grade.
    }
}

var classroom = Classroom(className: "Math", students: [
    Student(firstName: "Isaac", lastName: "Harry", grade: 80),
    Student(firstName: "Rev", lastName: "Titane", grade: 90),
    Student(firstName: "Brian", lastName: "Slabotsky", grade: 85)
    ])
classroom.getHighestGrade()

/*:
 Now make an extension on Classroom with a method names curveGrades(). This method should first find the difference between 100 and the highest grade, and addd that amount to all students scores. Then, it should sort the students array so it is ordered from the student with the higehst schore, to the one with the lowest. Remember structures are values types, so iterating with for student in students and attempting to modify students wont work.
 */

extension Classroom {
    mutating func curveGrades() {
        // Make a guard statement to see if there is a highest grade before proceeding further.
        guard let highestGrade = getHighestGrade() else {
            return
        }
        
        students = students.map { student in
            let curveAmount = 100 - highestGrade
            var student = student
            student.grade += curveAmount
            return student
        }
        
    }
}



//: [Next](@next)
