//: [Previous](@previous)


/*:
 ---
 ## Optionals
 ---
 */
struct Book {
    var name: String
    var publicationYear: Int? // In case there isnt a publicationYear yet.
}
let firstHarryPotterBook = Book(name: "Harry Potter and the Sorcerer's Stone", publicationYear: 1997)
let secondHarryPotterBook = Book(name: "Harry Potter and the Chamber of Secrets", publicationYear: 1998)
let thirdHarryPotterBook = Book(name: "Harry Potter and the Prisoner of Azkaban", publicationYear: 1999)

let books = [firstHarryPotterBook, secondHarryPotterBook, thirdHarryPotterBook]
let unfinishedBook = Book(name: "Rebels and Lions", publicationYear: nil)
//: Nil represents the absense of a value. It says "There is no value here."
//: If there was no "?" (optional) after Int, the app would crash.
//: When working with optionals, you must always declare the type, Swift cannot infer the type on its own.

/*:
---
 ### **Working with Optional Values**
 How do you determine if an optional contains a value?
 How do you access the value?
 
 By using force unwrapping, or the safer way with optional binding.
 
 **Optional Binding:**
 With optional binding, swift unwraps the optional, and if it contains a value, it assigns the value to a constant that is safe to work with.
 
 **Syntax:**
    if let constantName = someOptional {
        // Constant name is now safely unwrapped.
        }
 */
//: Function that contains a optional as a parameter.
func printFullName(firstName: String, middleName: String?, lastName: String) {
}

/*:
 ---
 ### **FAILABLE INITIALIZER**
 - Any initializer that might return nil, is called a failable initializer.
 - For greater control and safety, you might want to create your own failable initializer and define the logic for returning an instance, or nil.
 
 In this example, every Toddler must be given a name, as well as an age in months. However, you might not want to create an instance of a toddler if the child is younger than 12 months or older than 36 months. To provide this flexibility, you can use init? to define a failable initializer. The question mark (?) tells Swift that this initializer may return nil and that it should return an instance of type Toddler?.
 Within the body of the initializer, you can check if the given age is less than 12 or greater than 36. If either one is true, Swift will return nil instead of assigning a value to the age:
 */
struct Toddler {
    var name: String
    var monthsOld: Int
    
    init?(name: String, monthsOld: Int) {
        if monthsOld < 12 || monthsOld > 36 {
            return nil
        } else {
            self.name = name
            self.monthsOld = monthsOld
        }
    }
}
//: Use optional binding to safely unwrap the value before using it.
let possibleToddler = Toddler(name: "Isaac", monthsOld: 14)
if let toddler = possibleToddler {
    print("\(toddler.name) is \(toddler.monthsOld) months old")
} else {
    print("The age is not between 1 and 3 years of age.")
}
/*:
 ---
 ### **Optional Chaining**
 It is possible for an optional value, to have optional properties. These are called nested optionals.
 */
class Person {
    var age: Int
    var residence: Residence?
    
    init(age: Int, residence: Residence) {
        self.age = age
        self.residence = residence
    }
}
class Residence {
    var address: Address?
    
    init(address: Address) {
        self.address = address
    }
}
class Address {
    var buildingNumber: String
    var streetName: String
    var apartmentNumber: String?
    
    init(buildingNumber: String, streetName: String, apartmentNumber: String) {
        self.buildingNumber = buildingNumber
        self.apartmentNumber = apartmentNumber
        self.streetName = streetName
    }
}

/*: Explain this example:
 - Every address has a building number
 - Every address has a street name.
 - Every person has an age
 
 - Not every person has a residence.
 - Not every residence has an address
 - Not every address has an apartment number
 */

//: To unwrap this use optional chaining.
//: If a person has a residence, that residence will have an address, and that address has an apartment number.
let person = Person
if let theApartmentNumber = person.residence?.address?.apartmentNumber {
    print("the person lives at \(theApartmentNumber)")
}

/*:
---
### **More Optionals**
 - Optionals are containers that can have a value of a given type, or no value at all
 - We need to check first! */
var myNonOptionalString: String = "asdf"
var myOptionalString: String? = "asdf"
var middleName: String? = nil
/*: Why is it useful?
This is useful because it forces you to think about data integrity from the outset. Since Swift is strongly typed, your code will not compile until you have fully thought this through. Trade off is more upfront development work for more longterm code stability.

 In order to use a value contained inside an optional, you have to unwrap the optional first.
 Can either force-unwrap or safely unwrap - which do you think is better?
 You can force-unwrap an optional by adding an exclamation mark (!) onto the end of an optional variable name - don't do it! */

//myNonOptionalString = middleName <- compile-time error because `myNonOptionalString` is not allowed to be optional
//myNonOptionalString = middleName! <- runtime error if `middleName` is nil; force unwrapping is not advised
/*:
 ---
 **Optional Binding (If Let)**
 - This is the safest, recommended way to unwrap an optional.
 - An `if let` statement assigns the value inside the optional (if any) to a temporary constant (you can name it anything)
 - If the optional contains no value, it skips the body of the `if let`
 */
if let unwrappedMiddleName = middleName {
    // executes if `middleName` has a value
    // unwrappedMiddleName is a temporary constant with the value contained in `middleName`
    // The temporary constant is defined for the scope of the body of the `if let`
    print("My middle name is \(unwrappedMiddleName)")
}
else { // executes if `middleName` is nil
    print("I have no middle name")
}

//: Can use the same name when optional binding, but be careful as the original optional variable will no longer be available in the body of the `if let` (will be replaced with a temporary constant with the same name)
//: The reason this works is because the constant is scoped to the body of the `if let`, so it is technically a different scope from the original variable
if let middleName = middleName {
    print("Your middlename is \(middleName)") // safe unwrapping using optional binding (if let)
}

/*:
---
### **Advanced Dictionaries**
 Note: Accessing a value for a given key inside a dictionary will return it as optional, because the key may not exist.
Examples: Create a dictionary that describes a person (name, job, age) [String: String]. Create a conditional that prints out a person’s job. */
let dict = ["exampleKey": "exampleValue"]
print("\(dict["exampleKey"])")
print("\(dict["keyThatDoesntExist"])")

//: Dictionaries have no defined order, so in order to access the key value pairs with the keys sorted in ascending order, you can access the `keys` property on the dictionary, which will give you all the keys in an arbitrary order, and then call the `sorted()` function on them to sort them. Then, you can iterate over the sorted keys, access the value for each key, and perform any intended logic

for key in phoneBook.keys.sorted() {
    // Accessing values in a dictionary like this will give you an optional
    // You can alt-click `value` to verify its type is `String?`
    let value = phoneBook[key]
    print("\(key)'s phone number is \(value)")
    /*
     The right way to access values in a dictionary:
     Accessing values in a dictionary like this will give you the value as a non-optional, if it exists You can alt-click `value` to verify its type is `String` */
    if let value = phoneBook[key] {
        /* ^ This is not considered a redeclaration of `value` because this
        `value` is only defined within the body of the `if let`,
         and you are allowed to declare variables/constants with the
         same name in different scopes
         Keep in mind that if you have a number of variables with the
         same name declared in different scopes, the one in the current
         or nearest parent scope will be used */
        print("\(key)'s phone number is \(value)")
    }
}


//: [Next](@next)
