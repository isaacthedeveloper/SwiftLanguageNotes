//: [Previous](@previous)

import Foundation

/*:
 ---
 ## Big-O Notation
 ---
 
Big-O Notation is a way of describing the efficiency of an operation on a data structure. You could measure how much memory the data structure consumes, how much time an operation takes under the worst case scenario, or how much time an operation takes on average.
 
 ---
 ### O(1) -> Constant Time:
 
 No matter how many items are in a data structure, this function calls the same number of operations.
 
 - 1 item: 1 second
 - 10 items: 1 second
 - 100 items: 1 second
 
 **This is considered ideal performance.**
 
 ---
 ### **O(log n) -> Logarithmic:**
 
 The number of operations this function calls grows at the rate of the logarithm
 of the number of items in the data structure.
 
- 1 item: 1 second
- 10 items: 2 seconds
- 100 items: 3 seconds
 
 **This is good performance, since it grows slower than the number of items in the data structure.**
 
 ---
 ### **O(n) -> Linear:**

 The number of operations this function calls will grow linearly with the size of the structure.
 
- 1 item: 1 second
- 10 items: 10 seconds
- 100 items: 100 seconds
 
 **This is considered decent performance, but it can grind along wiht larger data collections.**
 
 ---
 ### **O(n (log n)) -> Linearithmic:**
 
 The number of opearitons called by this function grows by the logarithm of the number of items
 in the structure multiplied by the number of items in the structure.
 
 This is about the lowest level of real-world tolerance for performance.
 While larger data structures perform more operations, the increase is somewhat resonable for data structures with small numbers of items.
 
 ---
 ### **O(n^2) -> Quadratic:**

 The number of operations called by this function grows at a rate that equals the size of the data
 structure squared.
 
 This is poor performance at best. It grows quickly enough to become unusably slow even if you are working
 with small data structures.
 
 ---
 ### **O(2^n) -> Exponential:**

 The number of operations called by this function grows by two to the power of the size of the data structure.
 
 This is very poor performance and becomes slow imediately.
 
 ---
 ### **O(n!) -> Factorial:**

 The number of operations called by this function grows by the factorial of the size of the data structure.
 Essentially you have the worst case scenario for performance, For examplem in a structure with just 1-- items, the multip;ier of the number of opertaions is 158 digits long.
 
 ---

 ## **Big-O Notation with Data Structures:**

 
 **Expected Performance and When to Use Arrays:**
 
 Apple Documentation includes three key expections for Array performance.
 
 1 - Accessing any value at a particular index in an array is at worst 0(log n), but should usually be 0(1)
 
 2- Searching for an object at an unknown index is at worst 0(n (log n)), but will generally be 0(n)
 
 3- Inserting or deleting an object is at worst 0(n (log n)) but will often be 0(1)
 
 In english:
 1 - If you already know where an item is, then looking it up in the array should be fast.
 
 2 - If you dont know where a particular item is, youll need to look thorugh the array from begining to end, but the search will be slower.
 
 3 - If you know where you are adding or removing an object its not too difficult. Although, you may need to adjust the rest of the arrray afterwards, and thats more time consuming.
 
 **Expected Performance for Dictionaries:**

 1 - The performance degredation of getting a single value is guaranteed to be at worst 0(log n), but will often be 0(1).
 
 2 - Insertion and deletion can be as bad as 0(n (log n)) but typically closer to o(1) becuase of under the hood optimizations.
 
 **Arrays:**

 
 Arrays are stores as a continuous block in memory. That means if you have ten elements in an arrray, then ten values are all stores one next to the other.
 
 Accessing Elements: The cost of fetching an element is O(1). Since all the values are sequential, it is easy to use random access and fetch a value at a particular index. All the compiler needs to know is where the array starts and what index you want to fetch.
 
 Inserting Elements: The complexity of adding an element depends on the position in which you add the new element:
 - If you add to the beginning of the array, swift requires O(N) because it has to shift all of the elements over by one to make room.
 - Likewise, if you add to the middle of the array, all values from that index on need to be shifted over. Doing so will require N/2 operations, therefore running time is O(N).
 - If you add to the end of the array using appen and there is room, it will take O(1). If there is not room, swift will need to make space somewhere else and copy the entire array over before adding the new element, which will take O(N). The average case is O(1) though, because arrays are usually not full.
 
 Deleting Elements: Deleting an element leaves a gap where the removed element was. All elements in the array have to be sequential, so this gap needs to be closed by shifting elements forward.
 
 The complexity is simillar to inserting elements: If you are removing an element from the end, its an O(1) operation. Otherwise the complexity is O(N).
 
 Searching for an Element: If the element you are searching for is the first element in the array, then the search will end after a single operation. If the element does not exist you need to perfrom N operations until you realize that the element will take N/2 operations, thereforsre serching has a complexity of O(N).
 
 ---
 **Dictionaries:**

 
 In order to be able to examine how dictionaries work, you need to understand what HASHING is and how it works. Hashing is the process of transforming a value - String, Int, Bool, Double ect - to a numeric value, knowns as the hash value. This value can them be used to quickly lookup the values in a hashtable.
 Swift dictionaries have a type requirement for keys. Keys must be Hashable or you will get a compiler error.
 
 The hash value has to be deterministic meaning that a given valye must always return the same hash value. No matter how many times you calculate the hash value for some string, it will always give the same value.
 
 Accessing Elements: Getting the value for a given key is a constant time operation or O(1)
 Inserting Elements: To insert an element, the dictionary needs to calculate the hash value of teh key and then store data absed on that hash. These are all O(1) operations,
 Deleting Elements: The dictionary needs to calculate the hash value to know exactly where to find the elements, and the remove it. This is also an O(1)
 Searching for an Element: As mentioned above, accessing an element has a constant running time, so the complexity is also O(1)
 
 */
//: [Next](@next)
