//: [Previous](@previous)
//: # Model View Controller
//: ---
//: ## Model
//: **What** your application is, but not **how** it is displayed.
//:
//: - The view and the model should never speak to eachother.
//: - The model is UI independent so it should not talk to the view.
//: - The model cannot talk directly to the controller, instead it uses Notification and Key-Value Observing, and the Controller tunes in to listen.
//: - **Should always be a swift file**, not a cocoa class, because it does not speak to the UI. 
//:
//: ## View
//: Your **controllers** minions, this is everything like label, button, switched ect.
//: - The view and the model should never speak to eachother.
//: - The view can speak to the controller via outlets, and actions.
//: - Views cannot own the data they are displaying.
//:
//:
//: ## Controller
//: **How** your view shows up on the screen.
//:
//:  - Controllers can always talk to their **Model**.
//:  - Controllers can also talk directly to their **View**.
//:  - The controller sets itself as the views delegate so it can communicate to it.
//:  - The **delegate** is set via a protocol.
//:  - The controller sets itself as the data sources, so it can talk to the model, to update the view.
//:  - Controllers interpret / format **Model** information for the **View**.

//: [Next](@next)
