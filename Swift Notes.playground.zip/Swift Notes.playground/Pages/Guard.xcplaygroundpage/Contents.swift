//: [Previous](@previous)

// Function for Happy Birthday
func singHappyBirthday() {
    if birthdayIsToday {
        if invitedGuests > 0 {
            if cakeCandlesLit {
                print("Happy Birthday to you!")
            } else {
                print("The cake's candles haven't been lit.")
            }
        } else {
            print("It's just a family party.")
        }
    } else {
        print("No one has a birthday today.")
    }
}

// Guard for Happy Birthday
func singHappyBirthday() {
    guard birthdayIsToday else {
        print("No one has a birthday today.")
        return
    }
    guard invitedGuests > 0 else {
        print("It's just a family party.")
        return
    }
    guard cakeCandlesLit else {
        print("The cake's candles haven't been lit.")
        return
    }
    print("Happy Birthday to you!")
}

// Compare Func and Guard
func divide(_ number: Double, by divisor: Double) {
    if divisor != 0.0 {
        let result = number / divisor
        print(result)
    }
}

func divide(_ number: Double, by divisor: Double) {
    guard divisor != 0.0 else { return }
    let result = number / divisor
    print(result)
}

//: [Next](@next)
