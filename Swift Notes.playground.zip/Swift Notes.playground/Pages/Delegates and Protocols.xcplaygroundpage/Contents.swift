//: [Previous](@previous)

/*:
 ---
 
 ## Delegates:
 
 ---
 
 **How to become a delegate:**
 
 1) You declare yourself capable of being a delegate. To become the delegate for UITextField you need to include UITextFieldDelegate in the class line for the view controller. This tells the compiller that this particular view controller can actually handle the notifications messages that the text field sends to it.
 
 2) You let the object in question, lets say the UITextField, know that the view controller wishes to becomes its delegate. If you forget to tell the text field that it has a delegate, it will never send you any notifications.
 
 3) Implement the delegate methods. It makes no sense to become a delegate if you are not responding to the messages being sent!
 
 **General Rule: If Screen A launches Screen B then you do not want screen B to know too much about the screen that invoked it (A). The less B knows of A the better.**
 
 Ex: Screen A opens screen B. At some point screen B needs to communicate back to screen A, usually when it closes. The solution is to make Screen A the delegate of screen B, so that B can send its messages to A whenever it needs to. This is called loose coupling.
 
 It is customary for the delegate methods to have a reference to their owner as the first parameter. Doing this is not required, but is still a good idea. For example, in the case of table views, it may happen that an object is the delegate or data source for more than one table view. In that case, you need to be able to distinguish between those table views. To allow for this, the table view delegate methods have a parameter for the UITableView object that sent the notification. Having this reference also saves you from having to make an @IBOutlet for the table view. That explains why you pass self to your delegate methods. Recall that self refers to the object itself.
 
 ### Delegates in five easy steps:
 
 These are the steps for setting up the delegate pattern between two objects, where object A is the delegate for object Bm and object B will send messages back to A.
 
 1) Define a delegate protocol for object B.
 
 2) Give object B a delegate optional variable. This variable should be weak.
 
 3) Update object B to send messages to its delegate when something interesting happens, such as the user pressing the Cancel or Done buttons, or when it needs a piece of information. To do this you write:   delegate?.methodName(self,...)
 
 4) Make object A confrom to the delegate protocol. It should put the name of the protocol in its class line and implement the methods from the protocol.
 
 5) Tell object B that object A is now its delegate. (You should do this in the prepare for segue method)
 
 explained:
 First we define a protocol that contains the methods needed for the delegate.
 The methods will pass in a reference to the viewcontroller that called it.
 
 **Passing Data:**
 
 From A to B. When screen A opens screen B, A can give B the data it needs. You simply make a new instance variable in B’s view controller. Screen A then puts an object into this property right before it makes screen B visible, usually in prepare(for:sender:).
 
 To pass data back from B to A you use a delegate.
 
 **WEAK KEYWORD:**
 
 Use weak relationships to avoid what is known as an ownership cycle.
 When object A has a strong reference to object B, and at the samme time object B also has a strong reference back to A, then these two objects are involved in an ownership cycle which is bad.
 Normally an object is destroyed or deallocated when there are no more strong references to it, but because A and B have strong refrences to each other, they keep each other alive.
 The result is a potential memory leak where an object that ought to be destroyed, isnt, and the memory for its data is never reclaimed. With enough leaks, the app will crash.
 To avoid ownership cycles you make one of these references weak. In the case of a view controller and its delegate, screen A usually has a strong reference to screen Bm but B only has a weak reference back to its delegate which is A. Because of this, B no longer owns A.
 
 ---
 ### **Protocols:**
 
 Defines a new type that specifies property/method requirements for conforming objects
 Protocols define a specification without providing an implementation
 Allows you to think about what something can do rather than how it does it
 
 A protocol defines a set of requirements in the form of properties and/or methods
 Protocols define requirements, but no implementation
 Implementation comes from an adopting type such as a class
 A protocol is said to be ‘conformed to’ if a type implements all of the protocol’s requirements
 
 Name starts with a capital letter since it defines a new type, like a class or enumeration
 Protocols that describe what something is should read as nouns (e.g. Collection, Sequence).
 Protocols that describe a capability should be named using the suffixes able, ible, or ing (e.g. Equatable, ProgressReporting).
 A protocol normally does not implement any of the methods it declares. It just says: any object that conforms to this protocol must implement methods X,Y, and Z
 
 Example:
 
 A protocol is just a list of methods a class must implement. For example, TableViewController must have protocols such as number of sections, number of rows ect.
 */
protocol SimpleProtocol {
    //define protocol requirements
}

protocol MyProtocol {
    var gettablePropertyRequiredByMyProtocol: Bool { get } // could be implemented as a constant since no settable requirement
    var settablePropertyRequiredByMyProtocol: Bool { get set } // cannot be implemented as a constant since must be settable
    func aMethodRequiredByMyProtocol() -> Bool
}

class MyAdoptingClass: MyProtocol {
    let gettablePropertyRequiredByMyProtocol: Bool = true
    var settablePropertyRequiredByMyProtocol: Bool = false
    
    func aMethodRequiredByMyProtocol() -> Bool {
        return true
    }
}

class AnotherAdoptingClass: MyProtocol {
    var gettablePropertyRequiredByMyProtocol: Bool = false
    var settablePropertyRequiredByMyProtocol: Bool = true
    
    func aMethodRequiredByMyProtocol() -> Bool {
        return true
    }
}
//: If a class inherits from another class and conforms to protocols as well, the super class is listed first, followed by a comma-separated list of protocols adopted
class MySuperClass {
    
}

class MyAdoptingSubClass: MySuperClass, MyProtocol {
    let gettablePropertyRequiredByMyProtocol: Bool = true
    var settablePropertyRequiredByMyProtocol: Bool = false
    
    func aMethodRequiredByMyProtocol() -> Bool {
        return true
    }
}

let adopter1 = MyAdoptingClass()
let adopter2 = MyAdoptingSubClass()
let arrayOfObjectsAdoptingMyProtocol: [MyProtocol] = [adopter1, adopter2] // Polymorphism - Protocol defines a type - any object conforming to protocol is said to be of that type (can have multiple types simulatenously)

//: you can check whether an object is a certain type using the `is` operator
adopter2 is MyProtocol
adopter2 is MyAdoptingSubClass
adopter2 is MySuperClass

protocol Describable {
    var name: String? { get }
    var description: String? { get }
    var image: UIImage? { get }
}

class Person: Describable {
    var name: String?
    var description: String?
    var image: UIImage?
    
    init(name: String, description: String, image: UIImage?) {
        self.name = name
        self.description = description
        self.image = image
    }
}

class Place: Describable {
    var name: String?
    var description: String?
    var image: UIImage?
    var coordinates: CGPoint?
    
    init(name: String, description: String, image: UIImage?) {
        self.name = name
        self.description = description
        self.image = image
    }
}

class DetailView {
    var nameLabel: UILabel?
    var detailLabel: UILabel?
    var imageView: UIImageView?
    
    //    var personToDisplay: Person? // View is now coupled to the Person model -> What if we want to reuse UI for showing Places or Animals?
    // Protocols allow us to provide a specification for what kinds of objects can be displayed by this class
    var modelObjectToDisplay: Describable?
    
    func setupUI() {
        // optional chaining is a shortcut for optional binding using `if let`s
        // if the left side of an assignment operation is `nil`, the whole line doesn't execute
        // if the right side of an assignment operation evaluates to `nil`, then `nil` is assigned to the object on the left side
        self.nameLabel?.text = modelObjectToDisplay?.name
        self.detailLabel?.text = modelObjectToDisplay?.description
        self.imageView?.image = modelObjectToDisplay?.image
        
        // long form using `if let`s:
        if let nameLabel = self.nameLabel {
            if let modelObject = modelObjectToDisplay {
                nameLabel.text = modelObject.name
            }
            else {
                nameLabel.text = nil
            }
        }
        if let detailLabel = self.detailLabel {
            if let modelObject = modelObjectToDisplay {
                detailLabel.text = modelObject.description
            }
            else {
                detailLabel.text = nil
            }
        }
        if let imageView = self.imageView {
            if let modelObject = modelObjectToDisplay {
                imageView.image = modelObject.image
            }
            else {
                imageView.image = nil
            }
        }
        
    }
}
//: ---
//: ### Delegation using Protocols
//: Delegation is a design pattern whereby an object delegates work to another object

protocol Worker {
    func doWork()
}

class Manager: Worker {
    var employees: [Worker] = []
    func doWork() {
        // do work
        print("\(self.description) is managing")
        for employee in self.employees {
            employee.doWork()
        }
    }
    
    var description: String {
        return "\(String(describing: type(of: self)))"
    }
}

class Designer: Worker {
    func doWork() {
        print("draw some designs")
    }
    
    var description: String {
        return "\(String(describing: type(of: self)))"
    }
}

class Engineer: Worker {
    func doWork() {
        print("write some code")
    }
    
    var description: String {
        return "\(String(describing: type(of: self)))"
    }
}

class Employee: Worker {
    func doWork() {
        print("do work")
    }
    
    var description: String {
        return "\(String(describing: type(of: self)))"
    }
}

let delegator = Manager()
let delegate1 = Engineer()
let delegate2 = Designer()
delegator.employees = [delegate1, delegate2]

delegator.doWork()

//: Delegation can also be used to communicate important information

protocol ProgressObserver {
    func workHasStarted(by worker: Worker)
    func workHasFinished(by worker: Worker)
}

class ReportingEmployee: Employee {
    var progressObserver: ProgressObserver?
    
    override func doWork() {
        // optional chaining (if let shorthand)
        // if self.progressObserver == nil, nothing happens
        self.progressObserver?.workHasStarted(by: self)
        // do work
        super.doWork()
        self.progressObserver?.workHasFinished(by: self)
    }
}

class SupervisingManager: Manager, ProgressObserver {
    func supervise(employee: Worker) {
        print("\(self.description) is supervising")
    }
    
    func reviewWork(by employee: Worker) {
        print("\(self.description) is reviewing work")
    }
    
    // MARK: ProgressObserver
    
    func workHasStarted(by worker: Worker) {
        // do something
        self.supervise(employee: worker)
    }
    
    func workHasFinished(by worker: Worker) {
        // do something
        self.reviewWork(by: worker)
    }
}

let supervisor = SupervisingManager()
let worker1 = ReportingEmployee()
let worker2 = ReportingEmployee()
supervisor.employees = [worker1, worker2]

//supervisor.doWork() // forgot to set delegate - won't get notified

worker1.progressObserver = supervisor
worker2.progressObserver = supervisor
supervisor.doWork() // notifications work

var allStaff: [Worker] = [supervisor, worker1, worker2] // Polymorphism - Protocol defines a type - any object conforming to protocol is said to be of that type


// Protocols can be created with optional requirements
// Requires the use of the @objc decorator on the protocol and any optional requirement, since optional requirements in a protocol are an Objective-C feature
// However, in a pure Swift protocol, all requirements are required
// Before making a number of requirements optional, consider whether they'd be better split out into another protocol

@objc protocol ProtocolWithOptionalMethods {
    @objc optional func optionalMethod()
    func requiredMethod1()
}



//: [Next](@next)
