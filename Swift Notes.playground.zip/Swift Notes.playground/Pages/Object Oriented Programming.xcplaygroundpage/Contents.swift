/*:
 ---
 ## Intro Object oriented programming
 ---
 - Allows us to think of our programs in terms of objects that interact with each other to produce a desired behaviour.
 - Allows us to encapsulate code into discrete, logical chunks.
 - Objects can have properties (attributes) and methods (actions), just like objects in the real world.
 - A button is a good example of a real-world analog.
 - Based on your knowledge of apps, what are some examples of objects you may find in an app?
 - Get an example of a UI element, a data element.
 - What would their properties and methods be?
 
 ---
 ### **Classes: 'Blueprints' for objects:**
 - Classes define a new type and are declared with a capital first letter.
 - Made up of properties (attributes), methods (actions), and initializers (initial setup).
 - Classes contain properties and methods that describe the object and what it can do.
 - Properties an be read-only or read-write -> How might these be represented with what we know so far?
 - Methods are actions that the object can perform -> How might these be represented?
 - To actually create an object we need to make an instance of a class - process called instantiation.
 - E.g. If we have a blueprint for a building, we can use that blueprint to create any number of actual building objects.
 */
class SimpleClass {
    // most basic class (empty) - has no properties or methods
}
let anInstanceOfTheSimpleClass = SimpleClass()
let anotherInstanceOfTheSimpleClass = SimpleClass()
// ^ two distinct objects
/*:
 ---
 ### **Properties**
 - These are variables or constants that either describe the object or are used by the object during the course of its life.
 - The name 'property' is used when a variable/constant is owned by a class - this is indicated by declaring the variable/constant at the root level of the class.
 - Properties must have a value by the time a class is instantiated - can either be optional, have a default value, or be given a value during initialization (will talk about initialization a bit later).
 */
class SimplePerson {
    // read-write (var)
    let name: String = ""
    // read-only (let)
    var age: Int = 0
}
//:
//: **Working with Objects**
//:
//: Create objects using the class name and initialzer
let simplePersonObject = SimplePerson()
//: Access properties using dot syntax
let name: String = simplePersonObject.name
let age: Int = simplePersonObject.age
simplePersonObject.age = simplePersonObject.age + 1
simplePersonObject.age
/*:
 ---
 Methods
 - These are functions that describe the actions that an object can perform.
 - The name 'method' is used when a function is owned by a class.
 - Methods can be accessed using dot notation, which we’ve seen on arrays, for example (append, removeAtIndex).
 */
class SlightlyMoreComplexPerson {
    let name: String = ""
    var age: Int = 0
    
    func sayHello() {
        print("Hello!")
    }
    func haveBirthday() {
        // use `self` when the context is ambiguous or you just want to be explicit
        self.a ge = self.age + 1
        print(self.description())
    }
    func description() -> String {
        return "I am a person named \(self.name) and I am \(self.age) years old"
    }
}
//:
/*:
 ---
 What if we want to reference properties in our methods?
 ### **Self**
 - Whenever you refer to a method or property inside a class, you use the self keyword
 - Self literally means the object that contains the property/method
 - This is also useful when you have functions that take in parameters whose names conflict with existing properties
 - Technically, you only need to use `self` if the variable being referred to is ambiguous in the current context
 
 Ex. Write a `description()` method that return's the person's name and age
 Ex. Write a `haveBirthday()` method that increments a person's age and prints the person's description
 */
let anotherPerson = SlightlyMoreComplexPerson()
anotherPerson.age = 5
anotherPerson.haveBirthday()
anotherPerson.age
/*:
 ---
 ### **Initializers**
 - A special kind of method that is called when an object is created
 - Gives you an opportunity to set up an object before it is used
 - Ensures all non-optional properties have values before use
 - Safe-guards against using an object before it is set up
 - Don’t need tons of optional properties if you know they should always have a value
 */

//: Ex. try to create a class with a non-optional property with no default value. What happens? Why?
//:
class ClassWithNonOptionalProperties {
    var value: String // <- error without initializer
    
    init(value: String) {
        self.value = value // ambiguous without `self` usage
    }
}
//:
//: Ex. Create a new Person class that has non-optional properties and an initializer
//: Also has an optional phoneNumber and a friends list
//:
//: **Complex example**

class Person {
    // Properties - attributes that describe an object
    // Defined using `let` constants or `var` variables
    // Stored properties that are non-optional must have a value by the time they are initialized
    // Non-optional properties can either be declared with a default value, or initialized with a value by creating a custom initializer that will set these values
    let name: String
    var age: Int
    var phoneNumber: Int?
    var friends: [Person] = [] // you can use the name of the class in the class definition
    
    // Initializers - used to set up an object when it is created
    // Initializers do not have a return type
    // init(parameterName: parameterType, parameterName2: parameterType2, ...)
    init(name: String, age: Int) {
        // A custom initializer is required when a class has non-optional
        // properties without default values - the initializer must give
        // these properties values
        self.name = name
        self.age = age
    }
    
    // Methods - actions that an object can take
    // Defined using `func` functions
    func eat() {
        // Properties and methods of the class can be referenced using the `self` keyword
        print("\(self.name) is eating")
        self.printDescription()
    }
    
    func printDescription() {
        print("Hello, my name is \(self.name). I am \(self.age) years old.")
    }
}

//: Create objects using the class name and initialzer
let person1: Person = Person(name: "Stacey", age: 25)

//: Call methods using dot syntax
person1.eat()
person1.printDescription()

//: Multiple separate `Person`s can be created with their own unique characteristics
let person2: Person = Person(name: "Brian", age: 20)
person2.name
person2.age
person2.eat()
person2.printDescription()

var people: [Person] = [ person1, person2 ]


/*:
---
 ### Dictionaries vs Objects
 **Dictionary creation**
- Requires usage of `Any` value type annotation if storing heterogeneous types
- This allows you to store any type as values, and provides no type safety */
let personAsADictionary: [String: Any] = [ "name": "Stacey",
                                           "age": 25 ]
/*:
 **Accessing values from a dictionary**
- Requires a typecast to attempt to turn the `Any` value into the usable `String` type
- Also, all values accessed from a dictionary are implicitly optional since a value may not exist for a given key (even if it is not declared as optional)
- Forced type cast -> dangerous since it will crash if it cannot be converted into a `String` */
let name1 = personAsADictionary["name"] as! String
//: Optional typecast -> safe since it will skip over the body of the `if let` if the value cannot be converted into a `String`
if let name1 = personAsADictionary["name"] as? String {
    print("\(name1)")
}

//: **Class creation**

let personAsClass = Person(name: "Stacey", age: 25)

// Accessing values from an object
// No typecast since properties are declared with a type
let name2: String = personAsClass.name



/*:
 Exercise
- Create a class that describes a Square
- Property sideLength that is a Double
- Initializer that allows you to specify the sideLength
- Method area() that returns a Double (that calculates the correct area: length * width)
- Method perimeter() that returns a Double (that calculates the correct perimeter length: 2 * length + 2 * width)
- Method printDescription() that prints a description of the square, its area, and perimeter */

class Square {
    // Properties
    var sideLength: Double
    
    // Initializer
    init(sideLength: Double) {
        self.sideLength = sideLength
    }
    
    // Methods
    func area() -> Double {
        return self.sideLength * self.sideLength
    }
    
    func perimeter() -> Double {
        return self.sideLength * 4
    }
    
    func printDescription() {
        print("I am a square with area: \(self.area()), perimeter: \(self.perimeter())")
    }
}

let mySquare = Square(sideLength: 5)
mySquare.sideLength
mySquare.area()
mySquare.perimeter()
mySquare.printDescription()

/*:
---
 ### **Inheritance**
 
- One of the most powerful features of OOP is the ability for classes to inherit properties and methods from other classes.
- This lets you define things once in an ancestor class, and still be able to use them in child classes.
- Inherit properties, initializers, and methods from another class.
- Subclass inherits from Superclass and this can go multiple levels deep.
- Inheritance is declared after the class name by adding a colon (:) and the type being inherited from. */
class SoftwareDeveloper: Person {
    // This class `SoftwareDeveloper` (a subclass of `Person`) has access to `Person`'s properties and methods automatically
    // `Person` is referred to as the superclass
    // A subclass can have additional properties/methods which are unique to it
    var knownProgrammingLanguages: [String] = []
    
    func code() {
        if let language = knownProgrammingLanguages.first {
            print("I am coding \(language)")
        }
        else {
            print("I am still learning")
        }
    }
}

let developer = SoftwareDeveloper(name: "Amanda", age: 35)
developer.age
developer.name
developer.knownProgrammingLanguages.append("Swift")
developer.code()

/*:
 **Setting a custom initializer in the subclass**
- A subclass can add a custom initializer if the superclass's initializer is inappropriate
- An example of when this could happen is if a subclass has a new stored property that needs to have a value set at initialization time
 */
class Superhuman: Person {
    var superpower: String

    init(name: String, age: Int, superpower: String) {
        // General Initialization Order
        // 1) Assign values to any non-optional properties local to your class (i.e. not inherited)
        self.superpower = superpower
        
        // 2) Call superclass initializer if inheriting from another class using the `super` keyword - this initializes and assigns values to the properties declared in the superclass
        super.init(name: name, age: age)
        
        // 3) Perform any additional setup if needed
    }
}

/*:
 **Overriding Methods**
- Allows you to redefine the implementation of an inherited method
- Use the `override` keyword to decorate an overriden method
- Note: You can call still call the original implementation in your overriden implementation using `super`. */
class Button {
    var title: String?
    
    func press() {
        print("I was pressed")
    }
}

class RadioButton: Button {
    var enabled: Bool = false
    
    override func press() {
        // print("I was pressed")
        // ^ if we do this, we're duplicating logic. if it changes, we have to change it in more than one place
        // Instead, call superclass' implementation
        // `super` keyword is used to refer to the immediate inheriting class
        super.press()
        
        // long form
        //        if self.enabled {
        //            self.enabled = false
        //        }
        //        else {
        //            self.enabled = true
        //        }
        
        // short form
        self.enabled = !self.enabled
    }
}

let button = Button()
button.title = "Log in"

let radioButton = RadioButton()
radioButton.enabled
radioButton.title // <- RadioButton inherits the `title` property

/*:
 ---
 ### **Polymorphism**
 - Subclass types can be used wherever superclass types can be used
 
Ex.
var arrayOfButtons: [Button] = [ button, radioButton ] // `RadioButton`s are `Button`s
var arrayOfRadioButtons: [RadioButton] = [ button ] // <- `Button`s are not `RadioButton`s
 
 **Extra OOP**
*/
class Vehicle {
    var distanceTraveled: Double = 0
    let speed: Double
    let numberOfWheels: Int
    
    // Computed property
    var description: String {
        // can access the name of the Class using `String(describing: self)`
        let className = String(describing: type(of: self))
        return "\(className) moving at \(self.speed)m per move and has traveled \(self.distanceTraveled)m"
    }
    
    // Private property - can only be accessed from within the class definition
    private var privateProperty: String?
    // Property with a private setter - can have its value accessed from outside the class definition, but can only be set within the class definition
    private(set) var publiclyGettablePrivatelySettableProperty: String?
    
    init(speed: Double, numberOfWheels: Int) {
        self.speed = speed
        self.numberOfWheels = numberOfWheels
    }
    
    // Use methods to update the values of properties
    // Every time move is called, the `distanceTraveled` increases
    func move() {
        self.distanceTraveled = self.distanceTraveled + self.speed
    }
}

let vehicle = Vehicle(speed: 5, numberOfWheels: 4)
vehicle.distanceTraveled
vehicle.move()
vehicle.move()
vehicle.distanceTraveled
vehicle.description

//vehicle.privateProperty // <- error: cannot access private property outside class definition
//vehicle.publiclyGettablePrivatelySettableProperty = "Cannot do this" // <- error: cannot set property outside the class definition
vehicle.publiclyGettablePrivatelySettableProperty // okay since getting not setting
//: Creating other types of vehicles using inheritance
class Car: Vehicle {
    var isStarted: Bool = false
    
    init(speed: Double) {
        // customizable speed, hardcoded number of wheels
        super.init(speed: speed, numberOfWheels: 4)
    }
    
    override func move() {
        if self.isStarted {
            // don't repeat logic that is already defined
            //            self.distanceTraveled = self.distanceTraveled + self.speed
            // Use the superclass's implementation once we know the car is started
            super.move()
        }
        else {
            print("The car isn't started")
        }
    }
    
    func start() {
        self.isStarted = true
    }
}
let car = Car(speed: 120)
car.isStarted = true
car.move()
car.start()
car.move()

class Bike: Vehicle {
    init() {
        // hardcoded speed and number of wheels
        super.init(speed: 30, numberOfWheels: 2)
    }
}
let bike = Bike()


/*:
 **Bonus Exercise**
- Make a Race class that can simulate a race between 1 or more Vehicles
- Initializer with a trackLength, number of laps, array of Vehicles
- Properties: trackLength, number of laps, vehicles, winner?
- Methods:
- totalDistance() -> Int - returns the total length of the race
- runRace() -> Vehicle? - simulates a race and returns the winning vehicle */

class Race {
    var trackLength: Double
    var numberOfLaps: Int
    var winner: Vehicle?
    var vehicles: [Vehicle]
    
    init(trackLength: Double, numberOfLaps: Int, vehicles: [Vehicle]) {
        self.trackLength = trackLength
        self.numberOfLaps = numberOfLaps
        self.vehicles = vehicles
    }
    
    func totalDistance() -> Double {
        return self.trackLength * Double(numberOfLaps)
    }
    
    func runRace() -> Vehicle? {
        while self.winner == nil {
            for vehicle in vehicles {
                print(vehicle.distanceTraveled)
                vehicle.move()
                print("\(vehicle.description)")
                if vehicle.distanceTraveled >= self.totalDistance() && self.winner == nil {
                    self.winner = vehicle
                }
            }
        }
        if let winner = self.winner {
            print("The race is over! The winner is: \(winner.description)")
        }
        return self.winner
    }
    
}

let car1 = Car(speed: 60)
car1.start()
let bike1 = Bike()
let race = Race(trackLength: 400, numberOfLaps: 1, vehicles: [car1, bike1])

race.runRace()

/*:
---
 ### **Enumerations:**
 */
enum CompassPoint {
    case north
    case east
    case west
    case south
}

enum Planet {
    case earth, venus, mars, jupiter, mercury, saturn, uranus, neptune
}

var directionToHead = CompassPoint.west // Go west.
directionToHead = .east // Since it is defined above, we can use shorter syntax using the dot syntax.

//: Match enums with switch statement:
directionToHead = .south
switch directionToHead {
case .north:
    print("Go North")
case .south:
    print("Go South")
case .west:
    print("Go West")
case .east:
    print("Go East")
default:
    print("Check your spelling")
}

//: Iterating over Enumeration cases:
//: Enable this by typing :CaseIterable after the name of the enum.
enum Beverage: CaseIterable {
    case coffee
    case tea
    case juice
}
let numberOfChoices = Beverage.allCases.count
print("There aer \(numberOfChoices) drinks")

for beverage in Beverage.allCases {
    print(beverage)
}

/*:
 ---
 **WHEN SHOULD YOU SUBCLASS?**
 There are five concepts to determine when to subclass:
 1. Single Responsibilty
 - Each class should have only a single concern. It is better to delegate work to other classes to keep everything simple and clean.
 2. Type Safety
 - Subclassing gives a seperate type to the subclass which can be beneficial. For example, you can make a sports team that ONLY allows students rather than anyone, so here you would subclass Students.
 3. Shared Base Classes
 - Lets say you have different types of buttons in your app, such as image and text buttons. Storing a image and text in a button class is bad - it makes sense for the button to handle the pressed behaviour, while the subclass handles the look and feel of it.
 4. Extensibility
 -
 5. Identity
 - What objects are: Prefer classes and Inheritance
 - Whats objects can do: Prefer protocols & compositions
 */


