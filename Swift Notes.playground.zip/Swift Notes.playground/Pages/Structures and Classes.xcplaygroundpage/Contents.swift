
/*:
 ---
 
 ## Structures & Classes
 ---
 */
struct Resolution {
    // Stored Properties
    var width = 0
    var height = 0
}

class VideoMode {
    // Stored Properties
    var resolution = Resolution()
    var interlaced = false
    var framRate = 0.0
    var name: String?
}

//: Create Instances
let someResolution = Resolution()
let someVideoMode = VideoMode()
//: Access Properties using Dot Syntax

print("The width of someResolution is \(someResolution.width)")
print("The width of someVideoMode is \(someVideoMode.resolution.width)")

//: Use dot syntax to assign a new value to a variable property.
someVideoMode.resolution.width = 1280

/*:
 **Structures and Enumerations are value types.**
 
 - A value type is a type whose value is COPIED when assigned to a variable or constant, or even a function.
 
 The example below declared a constant hd and then a variable cinemas which was set to the currrent value of hd. Because Resolution is a structure, a copy of the existing instance is made, and this new copy is assigned to cinema. Even though hd and cinema now have the same width and height, they are two completely different instances behind the scenes. */
let hd = Resolution(width: 1920, height: 1080)
var cinema = hd
//: Next, the width property of cinema is amended to be the width of a wider screen.
cinema.width = 2048
print("Cinema is now \(cinema.width) pixels wide.") // Proves we changed cinema, but what about hd?
print("hd is \(hd.width) pixels wide.")
//: Why? because when cinema was given the current value of hd, the values stored in hd were copied into the new cinema instance. The end result is two completely seperate instances that contain the same numeric values. However, because they are seperate instances, setting the width of cinema to 2048 does not affect tehwidth stored in hd.
/*:
 ---
 ### Classes are reference types
 
Unlike value types, reference types are not copied when they are assigned to a variable or constant, or when they are passed into a function. Rather than a copy, a reference to the same existing instance is used. */

    struct Actor1 {
        let name: String
            var filmography1: [String] = []
 
 //:The function is marked as mutating since it will be modifying the filmography.
    mutating func signOnForSequel(franchiseName: String) {
        filmography1.append("Upcoming \(franchiseName) sequel")
        }
    }
 
//: This is not a good way to write it, because we want to eventually add to the array of movies so lets make this into a variable.
 
Actor1(name: "Leonardo DiCaprio", filmography1: ["Inception"])
var gotgStar = Actor1(name: "Zoe Saldana", filmography: ["Guardians of the Galaxy"])
 gotgStar.filmography.append("Avatar")
 
//: Assign gotg star to starTrekStar
 var starTrekStar = gotgStar
 starTrekStar.filmography.append("Star Trek")
 
//: write a method that lets the actor sign on for franchise sequels. So lets do that in the Actor Struct.
 
 var avatarStar = starTrekStar
//: Since the filmography is made up of movies with the same name as their franchises, we can loop through it to assign them.
 
        for franchiseName in avatarStar.filmography {
            avatarStar.signOnForSequel(franchiseName: franchiseName)
            }
 
                avatarStar.filmography
                starTrekStar.filmography
                gotgStar.filmography
 
/*:
 If all these variables refer to the same actress, why dont they have the same filmography?
 This happens because structures are value types - which means that everything their instances contain are copied on assignment.
 
 For example lets say you create a person structure with a first name isaac and last name ballas, and hren you assign person to another variable, instructor just like we did in the exercise.
 Even though you change the name, it still wont ever change because the values are independent.
 
 What we want instead is a reference rather than a value. The person should reference an instance of the person class (object)
 
 Lets convert the Actor value type to be a reference type.
 
 */

//: REWRITE THIS AS A CLASS
class Actor {
    let name: String
    var filmography: [String] = []
    
    init(name: String, filmography: [String]) {
        self.name = name
        self.filmography = filmography
    }
    
    func signOnForSequel(franchiseName: String) {
        filmography.append("Upcoming \(franchiseName) sequel")
    }
}

let gotgStar = Actor(name: "Zoe Saldana", filmography: ["Guardians of the Galaxy"])
gotgStar.filmography.append("Avatar")

let starTrekStar = gotgStar
starTrekStar.filmography.append("Star Trek")

let avatarStar = starTrekStar
let alienStar = Actor(name: "Sigourney Weaver", filmography: ["Alien"])
for franchiseName in avatarStar.filmography {
    avatarStar.signOnForSequel(franchiseName: franchiseName)
}
avatarStar.filmography
starTrekStar.filmography
gotgStar.filmography

/*:
 ---
 ### Classes vs. Structures instances
 
 **Structure:**
 - Equal if values are equal
 - imagine working out with two dumbells that weigh ten pounds each - theyre equal and you dont care which is for the right or left hand.
 
 **Classes:**
 - Unique identities. Even if they have the same values, they are still not considered to be the same.
 - For example, imagine two shoes, same color, size, and brand, as a class they would each be unique, ex: one for indoors and one for outdoors.
 
 Note: start with structures and convert to classes when necesarry.
 
 **STRUCTURE:**
 
 - value type
 - values
 - copy
 - immutable
 
 **CLASSES:**
 
 - reference types
 - objects
 - share
 - immutable
 
 ---
 ### Structures

 A structure is a named type that holds properties
 */

//: Structs can have default values
struct Odometer {
    var count: Int = 0
}
let odometer = Odometer()
print(odometer.count)

//: **Memberwise Initializers**

//: If you want to create a new instance with a non-default value. The memerberwise initializer allows you to set default values.

let odometer1 = Odometer(count: 1000)

/*:
 **Property Observers**
 
 Swift allows you to observe any property, and observe changes in the properties value. These property observers are called anytime a properties value is set.
 
In the following code a StepCounter has been defined with a totalSteps property. Both the willSet and didSet observers have been defined. Whenever totalSteps is modified, willSet will be called first, and you'll have access to the new value that will be set to the property value in a constant named newValue. After the property's value has been updated, didSet will be called, and you can access the previous property value using oldValue. */

struct StepCounter {
    var totalSteps: Int = 0 {
        willSet {
            print("Total steps is about to change to \(newValue)")
        } didSet {
            if totalSteps > oldValue {
                print("Added \(totalSteps - oldValue) steps")
            }
        }
    }
}

var stepCounter = StepCounter()
stepCounter.totalSteps = 40
stepCounter.totalSteps = 302








//: [Next](@next)
